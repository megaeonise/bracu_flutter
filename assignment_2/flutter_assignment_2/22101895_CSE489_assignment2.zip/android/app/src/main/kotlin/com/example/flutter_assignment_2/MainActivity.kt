package com.example.flutter_assignment_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
